# 조교의 성적 매기기

import sys
sys.stdin = open('ex.txt')